import pandas as pd
import numpy as np
from catboost import CatBoostClassifier

# 1. Define column names
column_names = [
    "age",
    "workclass",
    "fnlwgt",
    "education",
    "education_num",
    "marital_status",
    "occupation",
    "relationship",
    "race",
    "sex",
    "capital_gain",
    "capital_loss",
    "hours_per_week",
    "native_country",
    "income"
]

# 2. Define categorical columns
categorical_cols = [
    "workclass",
    "education",
    "marital_status",
    "occupation",
    "relationship",
    "race",
    "sex",
    "native_country"
]

# 3. Define numeric columns
numeric_cols = [
    "age",
    "fnlwgt",
    "education_num",
    "capital_gain",
    "capital_loss",
    "hours_per_week"
]

# 4. Load adult_test.csv
df_test = pd.read_csv(
    "Project_4_Income_Prediction/adult_test.csv",
    header=None,
    names=column_names,
    skipinitialspace=True,
    on_bad_lines="skip"
)

# 5. Strip spaces from text columns
for col in df_test.select_dtypes(include="object").columns:
    df_test[col] = df_test[col].astype(str).str.strip()

# 6. Replace ? with NaN
df_test = df_test.replace("?", np.nan)

# 7. Remove non-data rows by forcing age to numeric
df_test["age"] = pd.to_numeric(df_test["age"], errors="coerce")
df_test = df_test.dropna(subset=["age"])

# 8. Convert numeric columns properly
for col in numeric_cols:
    df_test[col] = pd.to_numeric(df_test[col], errors="coerce")

# 9. Fill missing categorical values
for col in categorical_cols:
    df_test[col] = df_test[col].fillna("Unknown")

# 10. Fill missing numeric values using training data medians
X_train_saved = pd.read_csv("Project_4_Income_Prediction/X_train.csv")
train_medians = X_train_saved[numeric_cols].median()

for col in numeric_cols:
    df_test[col] = df_test[col].fillna(train_medians[col])

# 11. Clean income labels if present
df_test["income"] = df_test["income"].astype(str).str.replace(".", "", regex=False).str.strip()

# 12. Keep only features
X_new = df_test.drop(columns=["income"], errors="ignore")

# 13. Make categorical columns string
for col in categorical_cols:
    X_new[col] = X_new[col].astype(str)

# Ensure column order matches training data
X_train_saved = pd.read_csv("Project_4_Income_Prediction/X_train.csv")

# Check missing columns
missing_cols = set(X_train_saved.columns) - set(X_new.columns)
if missing_cols:
    raise ValueError(f"Missing columns in inference data: {missing_cols}")

# Align column order
X_new = X_new[X_train_saved.columns]

# 14. Load trained model
model = CatBoostClassifier()
model.load_model("Project_4_Income_Prediction/catboost_best_model.cbm")

# 15. Load threshold chosen from validation set
threshold_df = pd.read_csv("Project_4_Income_Prediction/threshold_comparison_results.csv")
best_threshold = threshold_df.sort_values(by="validation_f1_score", ascending=False).iloc[0]["threshold"]

print("Using threshold from validation set:", best_threshold)

# 16. Predict probabilities
predicted_probabilities = model.predict_proba(X_new)[:, 1]

# 17. Predict classes using best threshold
predicted_labels = (predicted_probabilities >= best_threshold).astype(int)

# 18. Convert numeric predictions to income labels
predicted_income = np.where(predicted_labels == 1, ">50K", "<=50K")

# 19. Save output
output = X_new.copy()
output["predicted_probability"] = predicted_probabilities
output["predicted_label"] = predicted_labels
output["predicted_income"] = predicted_income

output.to_csv("Project_4_Income_Prediction/adult_test_predictions.csv", index=False)

print("Inference completed successfully.")
print("Predictions saved to Project_4_Income_Prediction/adult_test_predictions.csv")